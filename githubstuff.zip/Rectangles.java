public class Rectangles {
}
