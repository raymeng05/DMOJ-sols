import java.util.*;
import java.io.*;
public class Graphs {
    static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    static PrintWriter pr = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));
    static StringTokenizer st;
    static int n;
    static ArrayList<Integer>[] adj;
    static int[] parent;
    //try bidirectional bfs
    static int findParent(int p){
        if(p != parent[p]){
            parent[p] = findParent(parent[p]);
        }
        return parent[p];
    }
    static int bfs(int start, int end){
        boolean[] visited = new boolean[n+1];
        int[] dist = new int[n+1];
        Queue<Integer> q = new LinkedList<>();
        visited[start] = true;
        q.add(start);
        q.add(end);
        visited[end] = true;
        while(!q.isEmpty()){
            int cur = q.poll();
            for(int nxt: adj[cur]){
                if(!visited[nxt]){
                    q.add(nxt);
                    visited[nxt] = true;
                    dist[nxt] = dist[cur] + 1;
                }
            }
        }
        return dist[end]; //wrong
    }
    public static void main(String[] args) throws IOException {
        n = readInt();
        int m = readInt();
        int q = readInt();
        adj = new ArrayList[n+1];
        parent = new int[n+1];
        for(int i = 1; i<=n; i++){
            parent[i] = i;
        }
        for(int i = 1; i<=n; i++){
            adj[i] = new ArrayList<>();
        }
        for(int i = 0; i<m; i++){
            int x = readInt();
            int y = readInt();
            adj[x].add(y);
            adj[y].add(x);
            int rootX = findParent(x);
            int rootY = findParent(y);
            if(rootX == rootY){
                continue;
            }
            parent[rootX] = rootY;
        }
        for(int i = 0; i<q; i++){
            int a = readInt();
            int b = readInt();
            if(findParent(a) == findParent(b)){
                System.out.println(bfs(a, b));
            } else {
                System.out.println(-1);
            }
        }
    }

    static String next() throws IOException {
        while (st == null || !st.hasMoreTokens())
            st = new StringTokenizer(br.readLine().trim());
        return st.nextToken();
    }

    static long readLong() throws IOException {
        return Long.parseLong(next());
    }

    static int readInt() throws IOException {
        return Integer.parseInt(next());
    }

    static double readDouble() throws IOException {
        return Double.parseDouble(next());
    }

    static char readCharacter() throws IOException {
        return next().charAt(0);
    }

    static String readLine() throws IOException {
        return br.readLine().trim();
    }
}