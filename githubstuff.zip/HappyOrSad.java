import java.util.*;
import java.io.*;
public class HappyOrSad {
    static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    static PrintWriter pr = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));
    static StringTokenizer st;
    public static void main(String[] args) throws IOException {
        String s = readLine();
        int countHappy = 0;
        int countSad = 0;
        for(int i = 0; i<s.length()-3; i++){
            if(s.substring(i, i+3).equals(":-)")){
                countHappy++;
            } else if(s.substring(i, i+3).equals(":-(")){
                countSad++;
            }
        }
        if(countHappy == 0 && countSad == 0){
            System.out.println("none");
        } else if(countHappy == countSad){
            System.out.println("unsure");
        } else if(countHappy > countSad){
            System.out.println("happy");
        } else {
            System.out.println("sad");
        }
    }

    static String next() throws IOException {
        while (st == null || !st.hasMoreTokens())
            st = new StringTokenizer(br.readLine().trim());
        return st.nextToken();
    }

    static long readLong() throws IOException {
        return Long.parseLong(next());
    }

    static int readInt() throws IOException {
        return Integer.parseInt(next());
    }

    static double readDouble() throws IOException {
        return Double.parseDouble(next());
    }

    static char readCharacter() throws IOException {
        return next().charAt(0);
    }

    static String readLine() throws IOException {
        return br.readLine().trim();
    }
}









