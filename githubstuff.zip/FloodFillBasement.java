import java.util.*;
import java.io.*;
public class FloodFillBasement {
    static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    static PrintWriter pr = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));
    static StringTokenizer st;

    static class pair{
        int x;
        int y;

        public pair(int x, int y){
            this.x = x;
            this.y = y;
        }
    }
    public static void main(String args[]) throws IOException  {
        int x = readInt();
        int y = readInt();
        int xStart = readInt();
        int yStart = y+1-readInt();
        int[][] adj = new int[y+1][x+1];
        boolean[][] vis = new boolean[y+1][x+1];
        for(int i = 1; i<=y; i++){
            char[] arr = readLine().toCharArray();
            for(int j = 1; j<=x; j++){
                if(arr[j-1] == '*'){
                    vis[i][j] = true;
                }
            }
        }

        Queue<pair> q = new LinkedList();
        q.add(new pair(xStart, yStart));
        vis[yStart][xStart] = true;
        int[][] thing = {{0, 1}, {1, 0}, {0, -1}, {-1, 0}, {1, 1}, {1, -1}, {-1, -1}, {-1, 1}};

        while(!q.isEmpty()){
            pair temp = q.poll();
            int curX = temp.x;
            int curY = temp.y;

            for(int i = 0; i<8; i++){
                int newX = curX + thing[i][0];
                int newY = curY + thing[i][1];
                if(newX > 0 && newX <=x && newY > 0 && newY <= y && !vis[newY][newX]){
                    adj[newY][newX] = adj[curY][curX]+1;
                    vis[newY][newX] = true;
                    q.add(new pair(newX, newY));
                }
            }
            /*for(int i = 0; i<=y; i++){
                for(int j = 0; j<=x; j++){
                    System.out.print(adj[i][j] + " ");
                }
                System.out.println();*/

            if(q.isEmpty()){
                System.out.println(adj[curY][curX]);
                break;
            }
        }

    }

    static String next() throws IOException {
        while (st == null || !st.hasMoreTokens()) {
            st = new StringTokenizer(br.readLine().trim());
        }
        return st.nextToken();
    }

    static long readLong() throws IOException {
        return Long.parseLong(next());
    }

    static int readInt() throws IOException {
        return Integer.parseInt(next());
    }

    static double readDouble() throws IOException {
        return Double.parseDouble(next());
    }

    static char readCharacter() throws IOException {
        return next().charAt(0);
    }

    static String readLine() throws IOException {
        return br.readLine().trim();
    }
}