import java.util.*;
import java.io.*;
public class GiantAnts {
    static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    static PrintWriter pr = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));
    static StringTokenizer st;
    public static void main(String[] args) throws IOException {
        int numIntersections = readInt();
        int numHighways = readInt();
        List<Integer> adj[] = new ArrayList[numIntersections+1];
        for(int i = 1; i<=numIntersections; i++){
            adj[i] = new ArrayList<>();
        }
        for(int i = 1; i<=numHighways; i++){
            int u = readInt();
            int v = readInt();
            adj[u].add(v);
            adj[v].add(u);
        }
        int w = readInt();
        int dis[] = new int[numIntersections+1];
        Queue<Integer> q = new LinkedList<>();
        boolean[] vis = new boolean[numIntersections+1];
        for(int i = 1; i<=w; i++){
            int x = readInt();
            q.add(x);
            vis[x] = true;
        }
        while(!q.isEmpty()){
            int cur = q.poll();
            for(int nxt : adj[cur]){
                if(!vis[nxt]){
                    q.add(nxt);
                    vis[nxt] = true;
                    dis[nxt] = dis[cur]+4;
                }
            }
        }
        Arrays.fill(vis, false);
        int[] human = new int[numIntersections+1];
        q.add(1);
        vis[1] = true;
        while(!q.isEmpty()){
            int cur = q.poll();
            for(int nxt : adj[cur]){
                if(!vis[nxt] && human[cur] + 1 < dis[nxt]){
                    q.add(nxt);
                    vis[nxt] = true;
                    human[nxt] = human[cur] +1;
                }
            }
        }
        if(vis[numIntersections]){
            System.out.println(human[numIntersections]);
        } else {
            System.out.println("sacrifice bobhob314");
        }
    }



    static String next() throws IOException {
        while (st == null || !st.hasMoreTokens())
            st = new StringTokenizer(br.readLine().trim());
        return st.nextToken();
    }

    static long readLong() throws IOException {
        return Long.parseLong(next());
    }

    static int readInt() throws IOException {
        return Integer.parseInt(next());
    }

    static double readDouble() throws IOException {
        return Double.parseDouble(next());
    }

    static char readCharacter() throws IOException {
        return next().charAt(0);
    }

    static String readLine() throws IOException {
        return br.readLine().trim();
    }
}






