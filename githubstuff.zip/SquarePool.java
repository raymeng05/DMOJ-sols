public class SquarePool {
}
