import java.util.*;
import java.io.*;
public class HitchhikingFun {
    static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    static PrintWriter pr = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));
    static StringTokenizer st;
    static int n;
    static int[] distFromRoot;
    static class pair implements Comparable <pair>{
        int danger;
        int numRoads;
        public pair(int danger, int numRoads){
            this.danger = danger;
            this.numRoads = numRoads;
        }
        public int compareTo(pair e){
            if(danger != e.danger) {
                return Integer.compare(danger, e.danger);
            } else {
                return Integer.compare(numRoads, e.numRoads);
            }
        }
    }
    static class edge implements Comparable <edge>{
        pair thing;
        int node;
        public edge(pair thing, int node){
            this.thing = thing;
            this.node = node;
        }
        public int compareTo(edge e){
            return thing.compareTo(e.thing);
        }
    }


    public static void main(String[] args) throws IOException {
        n = readInt();
        int m = readInt();
        List<pair>[] adj = new ArrayList[n+1];

        for(int i = 1; i<=n; i++){
            adj[i] = new ArrayList<>();
        }
        for(int i = 0; i<m; i++){
            int a = readInt();
            int b = readInt();
            int t = readInt();
            adj[a].add(new pair(b, t));
            adj[b].add(new pair(a, t));
        }
        pair[] dist = new pair[n+1];
        for(int i = 1; i<=n; i++){
            dist[i] = new pair(m+1, m+1);
        }
        boolean[] vis = new boolean[n+1];
        PriorityQueue<edge> q = new PriorityQueue<>();
        dist[1] = new pair(0, 0);
        q.add(new edge(dist[1], 1));
        while(!q.isEmpty()){
            edge cur = q.poll();
            int curNode = cur.node;
            if(vis[curNode]){
                continue;
            }
            vis[curNode] = true;
            for(pair nxt: adj[curNode]){
                int nxtNode = nxt.danger;
                int w = nxt.numRoads;
                pair tmp = new pair(cur.thing.danger + w, cur.thing.numRoads+1);
                if(dist[nxtNode].compareTo(tmp) > 0){
                    dist[nxtNode] = tmp;
                    q.add(new edge(dist[nxtNode], nxtNode));
                }
            }
        }
        if(vis[n]) {
            System.out.println(dist[n].danger + " " + dist[n].numRoads);
        } else {
            System.out.println(-1);
        }

    }

    static String next() throws IOException {
        while (st == null || !st.hasMoreTokens())
            st = new StringTokenizer(br.readLine().trim());
        return st.nextToken();
    }

    static long readLong() throws IOException {
        return Long.parseLong(next());
    }

    static int readInt() throws IOException {
        return Integer.parseInt(next());
    }

    static double readDouble() throws IOException {
        return Double.parseDouble(next());
    }

    static char readCharacter() throws IOException {
        return next().charAt(0);
    }

    static String readLine() throws IOException {
        return br.readLine().trim();
    }
}